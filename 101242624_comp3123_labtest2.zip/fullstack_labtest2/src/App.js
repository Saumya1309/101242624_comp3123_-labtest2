import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Home } from './components/Home';

function App() {
  return (
    <div className="container">
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container-fluid justify-content-center">
          <a className="navbar-brand" href="#">Weather Forecast Application</a>
        </div>
      </nav>
      <Home />
    </div>
  );
}

export default App;

