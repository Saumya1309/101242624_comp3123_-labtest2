import React, { useState, useEffect } from 'react';
import * as WeatherService from '../services/Weather';

export const Home = () => {

    const [allData, setAllData] = useState({});
    const [todaysDetails, setTodaysDetails] = useState({});
    const [details, setDetails] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        WeatherService
            .getWeatherData()
            .then(data => {
                setAllData(data);
                setDetails(data.current);
                setTodaysDetails(data.current);
                debugger;
            })
            .catch(error => {
                setError(error.message);
            })
            .finally(() => {
                setLoading(false);
            })
    }, []);

    if (loading) {
        return (
            <div className="col-12">
                Loading...
            </div>
        )
    }

    if (error) {
        return (
            <div className="col-12">
                <div className="alert alert-danger">
                    Something went wrong!
                    { error }
                </div>
            </div>
        )
    }

    return (
        <div className="row">
            <div className="col-12">
                <h6>Weather Forcast Information</h6>
                <hr />
                <div className="row">
                    <div className="col card mx-2 p-0">
                        <div className="card-body p-0 text-center border border-2 border-info">
                            <img 
                                height={50}
                                width={50}
                                src={`http://openweathermap.org/img/wn/${todaysDetails.weather[0].icon}@2x.png`} />
                            <p className="small">
                                {
                                    WeatherService.convertKelvinToCelcius(todaysDetails.temp)
                                }°C
                            </p>
                            <p>
                                Today
                            </p>
                        </div>
                    </div>
                    {
                        allData.daily.map((dailyDetails, idx) => (
                            <div className="col card mx-2 p-0" key={idx}>
                                <div className="card-body p-0 text-center">
                                    <img 
                                        height={50}
                                        width={50}
                                        src={`http://openweathermap.org/img/wn/${dailyDetails.weather[0].icon}@2x.png`} />
                                    <p className="small">
                                        {
                                            WeatherService.convertKelvinToCelcius(dailyDetails.temp.day)
                                        }°C
                                    </p>
                                    <p>
                                        {
                                            new Date(dailyDetails.dt * 1000).getDate()
                                        }
                                    </p>
                                </div>
                            </div>
                        ))
                    }
                </div>
            </div>
            <div className="col-12 my-4">
                <h6 className="my-0">
                    Weather Information
                </h6>
                <hr />
                <div className="row justify-content-center">
                    <div className="col-2">
                        <img 
                            height={75}
                            width={75}
                            src={`http://openweathermap.org/img/wn/${details.weather[0].icon}@2x.png`} />
                    </div>
                    <div className="col-5">
                        <div>
                            { WeatherService.convertKelvinToCelcius(details.temp) } °Celcius
                        </div>
                        <div>
                            Toronto
                        </div>
                        <div className="text-capitalize">
                            <b>{ details.weather[0].description }</b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
