export async function getWeatherData() {
    const API_KEY = "112daf1e5a773959c59649ff1a4b0828";
    const request = await fetch("https://api.openweathermap.org/data/2.5/onecall?lat=43.6532&lon=-79.3832&appid=" + API_KEY);
    const response = await request.json();
    return response;
}

export function convertKelvinToCelcius(temperature) {
    if (typeof temperature !== "number") {
        throw "Temperature must be a number";
    }
    return (temperature - 273.15).toFixed(2);
}